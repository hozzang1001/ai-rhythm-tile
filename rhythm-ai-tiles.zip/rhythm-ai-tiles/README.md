
# Rhythm AI Tiles (Expo / React Native)

모바일 리듬게임 샘플 앱 — 곡 업로드 → AI 비트 검출 → 4레인 노트 생성 → 플레이

## 1) 의존성 설치
```bash
npm install -g expo eas-cli
npm install
```

## 2) 네이티브 모듈(FFmpeg) 사용을 위한 Prebuild
```bash
npx expo prebuild
```

## 3) 실행 (개발용)
```bash
npx expo run:android
# 또는
npx expo run:ios
```

## 4) APK 빌드 (설치 파일)
```bash
eas login
eas build:configure
eas build -p android --profile preview
```

빌드 완료 후 제공되는 링크에서 APK를 다운로드하세요.

---

### 참고
- 오디오 분석과 노트 생성 로직은 `App.tsx`에 포함되어 있습니다.
- 최초 실행 시 파일 권한 팝업이 뜰 수 있습니다.
