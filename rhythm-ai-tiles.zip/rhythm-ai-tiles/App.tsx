import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { SafeAreaView, View, Text, TouchableOpacity, Dimensions, StyleSheet, Alert } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import { Audio, AVPlaybackStatus } from 'expo-av';
import Svg, { Rect, Line } from 'react-native-svg';
import { FFmpegKit, ReturnCode } from 'ffmpeg-kit-react-native';
import { Buffer } from 'buffer';

if (typeof global.Buffer === 'undefined') {
  // @ts-ignore
  global.Buffer = Buffer;
}

interface Note {
  time: number;
  lane: number;
  hit?: boolean;
  judged?: boolean;
}

const lanes = 4;
const { width: W, height: H } = Dimensions.get('window');
const laneWidth = W / lanes;

function clamp(n: number, a: number, b: number) { return Math.max(a, Math.min(b, n)); }

function movingAverage(values: number[], win: number) {
  const out: number[] = new Array(values.length).fill(0);
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= win) sum -= values[i - win];
    out[i] = sum / Math.min(i + 1, win);
  }
  return out;
}

function pickPeaks(values: number[], threshold = 0.02, minDist = 6) {
  const peaks: number[] = [];
  let lastIndex = -minDist;
  for (let i = 1; i < values.length - 1; i++) {
    const v = values[i];
    if (v > threshold && v > values[i - 1] && v >= values[i + 1]) {
      if (i - lastIndex >= minDist) {
        peaks.push(i);
        lastIndex = i;
      }
    }
  }
  return peaks;
}

function buildChart(onsetsSec: number[], lanes = 4, minGap = 0.08) {
  const filtered: number[] = [];
  let prev = -999;
  for (const t of onsetsSec) {
    if (t - prev >= minGap) { filtered.push(t); prev = t; }
  }
  return filtered.map((t, i) => ({ time: t, lane: i % lanes }));
}

async function parseWavPCM16Mono(fileUri: string) {
  const b64 = await FileSystem.readAsStringAsync(fileUri, { encoding: FileSystem.EncodingType.Base64 });
  const bin = Buffer.from(b64, 'base64');
  const dataOffset = 44;
  const dataLen = bin.length - dataOffset;
  const samples = dataLen / 2;
  const out = new Float32Array(samples);
  for (let i = 0; i < samples; i++) {
    const lo = bin[dataOffset + i * 2];
    const hi = bin[dataOffset + i * 2 + 1];
    let v = (hi << 8) | lo; if (v & 0x8000) v = v - 0x10000;
    out[i] = v / 32768;
  }
  return out;
}

function detectOnsets(samples: Float32Array, sampleRate: number) {
  const frame = 2048, hop = 512;
  const frames = Math.floor((samples.length - frame) / hop);
  const energy = new Float32Array(frames);
  for (let i = 0; i < frames; i++) {
    let sum = 0; const start = i * hop;
    for (let j = 0; j < frame; j++) { const s = samples[start + j]; sum += s * s; }
    energy[i] = Math.sqrt(sum / frame);
  }
  const diff = new Float32Array(frames);
  for (let i = 1; i < frames; i++) diff[i] = Math.max(0, energy[i] - energy[i - 1]);
  const ma = movingAverage(Array.from(diff), 16);
  const adaptive = diff.map((v, i) => Math.max(0, v - ma[i] * 1.1));
  const peaks = pickPeaks(adaptive, 0.0005, 6);
  const onsetsSec = peaks.map((idx) => (idx * hop) / sampleRate).filter((t) => t > 0.3);

  const intervals: number[] = [];
  for (let i = 1; i < onsetsSec.length; i++) intervals.push(onsetsSec[i] - onsetsSec[i - 1]);
  intervals.sort((a, b) => a - b);
  const med = intervals.length ? intervals[Math.floor(intervals.length / 2)] : 0.5;
  const grid = med || 0.5;
  const snapped = onsetsSec.map((t) => Math.round(t / (grid / 2)) * (grid / 2));
  const unique = Array.from(new Set(snapped.map((v) => +v.toFixed(2)))).sort((a, b) => a - b);
  return unique;
}

export default function App() {
  const [audioUri, setAudioUri] = useState<string | null>(null);
  const [notes, setNotes] = useState<any[]>([]);
  const [sound, setSound] = useState<any>(null);
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [hitWindow, setHitWindow] = useState(0.12);
  const [goodWindow, setGoodWindow] = useState(0.22);

  const startTimeRef = React.useRef(0);

  const judgeY = H * 0.82;
  const speed = 340;

  React.useEffect(() => {
    return () => { if (sound) sound.unloadAsync(); };
  }, [sound]);

  const pickAudio = React.useCallback(async () => {
    const res = await DocumentPicker.getDocumentAsync({ type: 'audio/*', copyToCacheDirectory: true });
    if ((res as any).canceled || !(res as any).assets || !(res as any).assets[0]) return;
    const uri = (res as any).assets[0].uri;
    setAudioUri(uri);

    const out = FileSystem.documentDirectory + `conv_${Date.now()}.wav`;
    const cmd = `-y -i "${uri}" -ac 1 -ar 16000 -sample_fmt s16 "${out}"`;
    const session = await FFmpegKit.execute(cmd);
    const rc = await session.getReturnCode();
    // @ts-ignore
    if (!ReturnCode.isSuccess(rc)) {
      Alert.alert('변환 실패', '오디오 변환 중 문제가 발생했습니다.');
      return;
    }

    const data = await parseWavPCM16Mono(out);
    const onsets = detectOnsets(data, 16000);
    const chart = buildChart(onsets, 4, 0.08);
    setNotes(chart);
    setScore(0); setCombo(0);
  }, []);

  const play = React.useCallback(async () => {
    if (!audioUri) return;
    if (sound) await sound.unloadAsync();
    const { sound: s } = await Audio.Sound.createAsync({ uri: audioUri }, { shouldPlay: true });
    setSound(s);
    startTimeRef.current = Date.now() / 1000;
    setPlaying(true);
    s.setOnPlaybackStatusUpdate((st: any) => {
      if (!st.isLoaded) return;
      if (st.didJustFinish) setPlaying(false);
    });
  }, [audioUri, sound]);

  const currentTime = () => (Date.now() / 1000) - (startTimeRef as any).current;

  const judgeTap = React.useCallback((lane: number) => {
    if (!playing) return;
    const now = currentTime();
    let idx = -1, best = 999;
    notes.forEach((n: any, i: number) => {
      if (n.lane !== lane || n.judged) return;
      const d = Math.abs(n.time - now);
      if (d < best) { best = d; idx = i; }
    });
    if (idx >= 0) {
      const d = Math.abs(notes[idx].time - now);
      const copy = [...notes];
      copy[idx].judged = true; copy[idx].hit = d <= goodWindow;
      if (d <= hitWindow) { setScore((s) => s + 1000 * (1 - d / hitWindow) + combo * 5); setCombo((c) => c + 1); }
      else if (d <= goodWindow) { setScore((s) => s + 300); setCombo((c) => c + 1); }
      else { setCombo(0); }
      setNotes(copy);
    }
  }, [notes, playing, combo, hitWindow, goodWindow]);

  const tiles = React.useMemo(() => {
    const now = playing ? currentTime() : 0;
    const tileH = 90;
    return notes.filter((n: any) => !n.hit).map((n: any, i: number) => {
      const y = judgeY - (n.time - now) * speed;
      const x = n.lane * (W / 4) + 6;
      const w = (W / 4) - 12;
      return <Rect key={i} x={x} y={y - tileH} width={w} height={tileH} fill="#000" opacity={clamp(1 - Math.abs(n.time - now) / 1.2, 0.2, 1)} />;
    });
  }, [notes, playing]);

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.btn} onPress={pickAudio}><Text style={styles.btnText}>곡 선택</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.btn, { backgroundColor: playing ? '#f43' : '#34d399' }]} onPress={play} disabled={!audioUri}>
          <Text style={styles.btnText}>{playing ? '재생 중' : '재생'}</Text>
        </TouchableOpacity>
        <Text style={styles.info}>노트 {notes.length}개</Text>
      </View>

      <View style={{ flex: 1 }}>
        <Svg width={W} height={H}>
          {[0,1,2,3].map(i => (
            <Rect key={i} x={(W/4)*i} y={0} width={W/4} height={H} fill={i%2?'#ffffff10':'#ffffff05'} />
          ))}
          <Line x1={0} x2={W} y1={H*0.82} y2={H*0.82} stroke="#fff" strokeOpacity={0.8} strokeWidth={2} />
          {tiles}
        </Svg>

        <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, flexDirection: 'row' }} pointerEvents="box-none">
          {[0,1,2,3].map((lane) => (
            <TouchableOpacity key={lane} style={{ flex: 1 }} onPress={() => judgeTap(lane)} />
          ))}
        </View>
      </View>

      <View style={{ padding: 12, alignItems: 'center' }}>
        <Text style={{ color: '#fff' }}>Score {Math.round(score)} · Combo {combo}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#5b63ff' },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, gap: 8, paddingTop: 8 },
  btn: { backgroundColor: '#334155', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 14 },
  btnText: { color: 'white', fontWeight: 'bold' },
  info: { marginLeft: 'auto', color: '#fff' },
});
